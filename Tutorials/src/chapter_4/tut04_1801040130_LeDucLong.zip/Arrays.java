package chapter_4;

public class Arrays {

    /**
     * Count the number of even elements of an array that are negative
     * @requires a is not null
     * @effects return the number of negative elements in a
     * out = [ x | x in a /\ x < 0 ].length
     */
    public static int countNegatives(int[] a) {
        return 0;
    }

    /**
     * Count the number of even elements of an array of positive integers
     * @requires a is not null
     * @effects return the number of even elements in a
     * out = [ x | x int a /\ x % 2 == 0 ].length
     */
    public static int countEvens(int a) {
        return 0;
    }

    /**
     * Divide the elements of a real number array by a real number
     * @requires a != null /\ x != 0
     * @effects
     * return [a / x | a in x_0]
     */
    public static float[] divArray(float[] a, float x){
        return null;
    }

    /**
     * Find the minimum element in an array of integers
     * @requires a != null
     * @effects return the minimum element in a
     */
    public static int min(int[] a){
        return 0;
    }

    /**
     * Determine whether an array of integers is in ascending order
     * @requires a is not null
     * @effects
     * if a is in ascending order
     *      return true
     * else
     *      return false
     */
    public static boolean isAscSorted(int[] a){
        return false;
    }

    /**
     * Find the median of an array of reals
     * @requires a is not null
     * @effects
     * if a.length % 2 == 0
     *      return (a[a.length/2] + a[a.length/2 - 1]) / 2
     * else
     *      return a.[a.length / 2]
     */
    public static float median(float[] a){
        return 0;
    }

    /**
     *
     */
    /**
     * Compute the frequencies of each element of an array of reals
     * @requires
     * @effects
     *  let F(x) be the frequency of x in a
     *  frequency of x in a is the number of occurrences of x in a
     *  out = [F(u) | y in a]
     *  E.g. a = {3, 5, 5, 6}, out = {1, 2, 2, 1}
     *
     *  if a is not null
     *      return out
     *  else
     *      return null
     */
    public static int[] freq(float[] a){
        return null;
     }
}
